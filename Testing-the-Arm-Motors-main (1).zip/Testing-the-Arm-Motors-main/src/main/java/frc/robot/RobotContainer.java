// Copyright (c) FIRST and other WPILib contributors.
// Open Source Software; you can modify and/or share it under the terms of
// the WPILib BSD license file in the root directory of this project.

package frc.robot;

import frc.robot.Constants.OIConstants;
import frc.robot.Constants.OperatorConstants;
//import frc.robot.commands.Autos.ArmDownAuto;
import frc.robot.commands.Autos.Autos;
//import frc.robot.commands.Autos.ElevatorAuto;
//import frc.robot.commands.Autos.OutTakeAuto;
import frc.robot.commands.Teleop.ExampleCommand;
import frc.robot.commands.Teleop.WristCommand;
import frc.robot.commands.Teleop.WristPIDCommand;
import frc.robot.commands.Teleop.ZeroArmCommand;
import frc.robot.commands.Teleop.ZeroHeadingCommand;
import frc.robot.commands.Teleop.HarpoonCommand;
import frc.robot.commands.Teleop.IntakeCommand;
import frc.robot.commands.Teleop.SpeedCommand;
import frc.robot.commands.Teleop.TargetLeftPoleCommand;
import frc.robot.commands.Teleop.ArmCommand;
import frc.robot.commands.Teleop.ArmPIDCommand;
import frc.robot.commands.Teleop.ZeroArmCommand;
import frc.robot.commands.Teleop.ElevatorCommand;
import frc.robot.commands.Teleop.ElevatorPIDCommand;
import frc.robot.subsystems.*;
import frc.robot.commands.Autos.ElevateUp;
import frc.robot.commands.Autos.ArmUp;
import frc.robot.commands.Autos.ArmDown;
import frc.robot.commands.Autos.WristUp;
import frc.robot.commands.Autos.IntakeIn;
import frc.robot.commands.Autos.WristDown;
import frc.robot.commands.Autos.ElevateDown;
import frc.robot.commands.Autos.IntakeOut;
import com.pathplanner.lib.commands.PathPlannerAuto;
import com.pathplanner.lib.auto.AutoBuilder;
import edu.wpi.first.math.MathUtil;
import edu.wpi.first.wpilibj.AnalogPotentiometer;
import edu.wpi.first.wpilibj.Joystick;
import edu.wpi.first.wpilibj.XboxController;
import edu.wpi.first.wpilibj2.command.Command;
import edu.wpi.first.wpilibj2.command.InstantCommand;
import edu.wpi.first.wpilibj2.command.ParallelCommandGroup;
import edu.wpi.first.wpilibj2.command.RunCommand;
import edu.wpi.first.wpilibj2.command.SequentialCommandGroup;
import edu.wpi.first.wpilibj2.command.button.CommandJoystick;
import edu.wpi.first.wpilibj2.command.button.CommandXboxController;
import edu.wpi.first.wpilibj2.command.button.JoystickButton;
import edu.wpi.first.wpilibj2.command.button.POVButton;
import edu.wpi.first.wpilibj2.command.button.Trigger;
import edu.wpi.first.wpilibj.PS4Controller.Button;
import edu.wpi.first.wpilibj.XboxController.Axis;
import com.pathplanner.lib.auto.NamedCommands;
import com.pathplanner.lib.commands.PathPlannerAuto;
import edu.wpi.first.wpilibj.smartdashboard.SendableChooser;
import edu.wpi.first.wpilibj.smartdashboard.SmartDashboard;
/*
 * This class is where the bulk of the robot should be declared. Since Command-based is a
 * "declarative" paradigm, very little robot logic should actually be handled in the {@link Robot}
 * periodic methods (other than the scheduler calls). Instead, the structure of the robot (including
 * subsystems, commands, and trigger mappings) should be declared here.
 */
public class RobotContainer {
  // The robot's subsystems and commands are defined here...
  private final ExampleSubsystem m_exampleSubsystem = new ExampleSubsystem();
  private final ElevatorSubsystem elevatorSubsystem = new ElevatorSubsystem();
  private final HarpoonSubsystem harpoonSubsystem = new HarpoonSubsystem();
  private final ArmSubsystem armSubsystem = new ArmSubsystem();
  private final WristSubsystem wristSubsystem = new WristSubsystem();
  private final IntakeSubsystem intakeSubsystem = new IntakeSubsystem();
  private final LimelightSubsystem limelightSubsystem = new LimelightSubsystem();

  public static Joystick m_driverController = new Joystick(OIConstants.kDriverControllerPort);
  public static Joystick turncontroller = new Joystick(OIConstants.turncontrollerport);
  public static CommandXboxController xbxController = new CommandXboxController(1);
  private final DriveSubsystem m_robotDrive = new DriveSubsystem(); 
  public static double drive_inputX;
  public static double drive_inputY;
  public static double drive_inputZ;

  //private final SendableChooser<Command> autoChooser;

  
  
 
 
  //double txnc = LimelightHelpers.getTXNC("");  // Horizontal offset from principal pixel/point to target in degrees
  //double tync = LimelightHelpers.getTYNC("");  // Vertical  offset from principal pixel/point to target in degrees

  //set flight stick buttons

   //private JoystickButton cmdintake = new JoystickButton(turncontroller, 1);
  // private JoystickButton cmdouttake = new JoystickButton(m_driverController, 1);
   
  
   private POVButton cmdElevatorUp = new POVButton(turncontroller, 0);
   private POVButton cmdElevatorDown = new POVButton(turncontroller, 180);
   //PID Command buttons
   //private JoystickButton cmdElevatorUpPID = new JoystickButton(turncontroller, 2);
   private POVButton cmdArmUp = new POVButton(turncontroller, 270);
   private POVButton cmdArmDown = new POVButton(turncontroller, 90);
   //private JoystickButton cmdArmPID = new JoystickButton(turncontroller, 7);
   //private JoystickButton cmdArmDown = new JoystickButton(turncontroller, 6);
   private POVButton cmdWristDown = new POVButton(m_driverController, 0);
   private POVButton cmdWristUp = new POVButton(m_driverController, 180);
   private JoystickButton cmdHarpoonDown = new JoystickButton(m_driverController, 4);
   private JoystickButton cmdHarpoonUp = new JoystickButton(turncontroller, 10);
   private JoystickButton cmdIntakeIn = new JoystickButton(turncontroller, 1);
   private JoystickButton cmdIntakeOut = new JoystickButton(m_driverController, 1);
   //private JoystickButton cmdWristPID = new JoystickButton(m_driverController, 6);
  // private JoystickButton cmdtopCoral = new JoystickButton(m_driverController, 6);
   //private JoystickButton cmdmidCoral = new JoystickButton(m_driverController, 4);
  // private JoystickButton cmdbottomCoral = new JoystickButton(m_driverController, 3);
   //private JoystickButton cmdarmtofeeder = new JoystickButton(turncontroller, 9);
   //private JoystickButton cmdfloorball = new JoystickButton(turncontroller, 3);
  

  // private JoystickButton cmdHalfSpeed = new JoystickButton(turncontroller, 10);

   //private JoystickButton cmdarmtofloor = new JoystickButton(turncontroller, 9);
//   private JoystickButton zeroArm = new JoystickButton(turncontroller, 7);

   private JoystickButton cmdZeroHeading = new JoystickButton(m_driverController, 11);

   private JoystickButton cmdMoveRobotl = new JoystickButton(turncontroller, 2);
   private JoystickButton cmdMoveRobotr = new JoystickButton(turncontroller, 3);
   private JoystickButton cmdMoveRobottl = new JoystickButton(turncontroller, 5);
   private JoystickButton cmdMoveRobottr = new JoystickButton(turncontroller, 6);


   

  
  
//Commented out Because xbox controller was changed to a Command Controller 
  //set Xbox controller buttons 

  
   //private JoystickButton xboxlfttrig = new JoystickButton(xbxController, 0)
   //private GamepadAxisButton xboxrighttrig = new GamepadAxisButton(this::XBXRightTrig);

   /*  private JoystickButton xouttake = new JoystickButton(xbxController, 7);
   private JoystickButton xelevatorUp = new JoystickButton(xbxController, 4);
   private JoystickButton xelevatorDown = new JoystickButton(xbxController, 1);
   private JoystickButton xwristDown = new JoystickButton(xbxController, 6);
   private JoystickButton xwristUp = new JoystickButton(xbxController, 5);
   private JoystickButton xarmUp = new JoystickButton(xbxController, 3);
   private JoystickButton xarmDown = new JoystickButton(xbxController, 2);
*/

   


  // Replace with CommandPS4Controller or CommandJoystick if needed
 

  
  

  /** The container for the robot. Contains subsystems, OI devices, and commands. */
  public RobotContainer() {
    
    // Configure the trigger bindings
   


          //  -MathUtil.applyDeadband(m_driverController.getY() / 2, OIConstants.kDriveDeadband),
          //  -MathUtil.applyDeadband(m_driverController.getX() / 2, OIConstants.kDriveDeadband),
          //  -MathUtil.applyDeadband(turncontroller.getZ() *0.75, 0.4),
   //NamedCommands.registerCommand("ElevateUp", new ElevatorAuto(elevatorSubsystem).withTimeout(1));
   //NamedCommands.registerCommand("ArmDown", new ArmDownAuto(armSubsystem).withTimeout(1));
   
   NamedCommands.registerCommand("elevateUp", ElevateUp.elevatorAuto(elevatorSubsystem).withTimeout(4.5));
   NamedCommands.registerCommand("ArmDown", ArmDown.armAuto(armSubsystem).withTimeout(1));
   //NamedCommands.registerCommand("EArmDown", ArmDown.armAuto(armSubsystem).until(potentiometer1 = 0.4));
   NamedCommands.registerCommand("ArmUp", ArmUp.armAuto(armSubsystem).withTimeout(1));
   NamedCommands.registerCommand("WristUp", WristUp.wristAuto(wristSubsystem).withTimeout(0.7));
   NamedCommands.registerCommand("IntakeIn", IntakeIn.intakeAuto(intakeSubsystem).withTimeout(0.2));
   NamedCommands.registerCommand("elevateDown", ElevateDown.elevatorAuto(elevatorSubsystem).withTimeout(1));
   NamedCommands.registerCommand("WristDown", WristDown.wristAuto(wristSubsystem).withTimeout(0.7));
   NamedCommands.registerCommand("IntakeIn longer", IntakeIn.intakeAuto(intakeSubsystem).withTimeout(0.9));
   NamedCommands.registerCommand("elevateUp", ElevateUp.elevatorAuto(elevatorSubsystem).withTimeout(3));
   NamedCommands.registerCommand("elevateDown 2", ElevateDown.elevatorAuto(elevatorSubsystem).withTimeout(1.7));
   NamedCommands.registerCommand("Intakeout", IntakeOut.intakeAuto(intakeSubsystem).withTimeout(0.2));
   NamedCommands.registerCommand("elevateUp 2", ElevateUp.elevatorAuto(elevatorSubsystem).withTimeout(1.6));
   NamedCommands.registerCommand("Intakeout longer", IntakeOut.intakeAuto(intakeSubsystem).withTimeout(2));
   NamedCommands.registerCommand("elevateUp 3", new ElevatorPIDCommand(elevatorSubsystem, 0.288).withTimeout(1.0));
   //NamedCommands.registerCommand("elevateUp 3", ElevateUp.elevatorAuto(elevatorSubsystem).withTimeout(0.8));
   NamedCommands.registerCommand("LimeLight Target Left", new TargetLeftPoleCommand(m_robotDrive, limelightSubsystem, 0, 0, 2).withTimeout(3));
   NamedCommands.registerCommand("LimeLight Target Right", new TargetLeftPoleCommand(m_robotDrive, limelightSubsystem, 0, 0, 1));
   NamedCommands.registerCommand("elevateUp L2", new ElevatorPIDCommand(elevatorSubsystem, 0.48));//.withTimeout(1.0));
   NamedCommands.registerCommand("Arm L2", new ArmPIDCommand(armSubsystem, 0.61));//.withTimeout(1.0));
   NamedCommands.registerCommand("Wrist L2", new WristPIDCommand(wristSubsystem, 0.58));//.withTimeout(1.0));
   NamedCommands.registerCommand("IntakeOut K", new IntakeCommand(intakeSubsystem, -1, -1).withTimeout(1.0));
   NamedCommands.registerCommand("IntakeIn K", new IntakeCommand(intakeSubsystem, 1, 1).withTimeout(1.0));

   NamedCommands.registerCommand("elevateUp L3", new ElevatorPIDCommand(elevatorSubsystem, 0.31));//.withTimeout(1.0));
   NamedCommands.registerCommand("elevateUp L4", new ElevatorPIDCommand(elevatorSubsystem, 0.18));//.withTimeout(1.0));
   NamedCommands.registerCommand("Arm L4", new ArmPIDCommand(armSubsystem, 0.395));//.withTimeout(1.0));
   NamedCommands.registerCommand("Wrist L4", new WristPIDCommand(wristSubsystem, 0.64).withTimeout(3.0));
   NamedCommands.registerCommand("elevateUp H", new ElevatorPIDCommand(elevatorSubsystem, 0.59));
   NamedCommands.registerCommand("Arm H", new ArmPIDCommand(armSubsystem, 0.3));
   NamedCommands.registerCommand("Wrist H", new WristPIDCommand(wristSubsystem, 0.58).withTimeout(3.0));

   NamedCommands.registerCommand("elevateToBall", new ElevatorPIDCommand(elevatorSubsystem, 0.39));//.withTimeout(1.0));

   configureButtonBindings();
   m_robotDrive.setDefaultCommand(
      // The left stick controls translation of the robot.
      // Turning is controlled by the X axis of the right stick.
       new RunCommand(
           () -> m_robotDrive.drive(
               drive_inputX,
               drive_inputY,
               drive_inputZ,
               true),
           m_robotDrive));
    autoChooser = AutoBuilder.buildAutoChooser();
    //autoChooser.setDefaultOption("Elevator Auto", ElevateUp.elevatorAuto(elevatorSubsystem));
    

    SmartDashboard.putData("Auto Chooser", autoChooser);

    
  }

 


  public double getJoystickValue(double stickVal) {
    if(Math.abs(stickVal) < OperatorConstants.kJoystickDeadzone) return 0;
    else return stickVal;
}


  /**
   * Use this method to define your trigger->command mappings. Triggers can be created via the
   * {@link Trigger#Trigger(java.util.function.BooleanSupplier)} constructor with an arbitrary
   * predicate, or via the named factories in {@link
   * edu.wpi.first.wpilibj2.command.button.CommandGenericHID}'s subclasses for {@link
   * CommandXboxController Xbox}/{@link edu.wpi.first.wpilibj2.command.button.CommandPS4Controller
   * PS4} controllers or {@link edu.wpi.first.wpilibj2.command.button.CommandJoystick Flight
   * joysticks}.
   */

   private SendableChooser<Command> autoChooser = new SendableChooser<>();
   
  private void configureButtonBindings() {
    
    // Schedule `ExampleCommand` when `exampleCondition` changes to `true`
    // new Trigger(m_exampleSubsystem::exampleCondition)
    //     .onTrue(new ExampleCommand(m_exampleSubsystem));

    //cmdintake.whileTrue(new setIntake(1.0, m_intakeSubsystem));
    //cmdouttake.whileTrue(new setIntake(-1.0, m_intakeSubsystem));
    
    //xboxrighttrig.whileTrue(new Shoot_Speaker(m_ShootingSubsystem));
    //xboxlfttrig.whileTrue(new setIntake(1.0, m_intakeSubsystem));
    //cmdElevatorDown.whileTrue(System.out.println("works"));
   
    
   
   // Calling the Command to move the elevator and passing through speed and direction. 
    cmdElevatorUp.whileTrue(new ElevatorCommand(elevatorSubsystem,1));
    cmdElevatorDown.whileTrue(new ElevatorCommand(elevatorSubsystem, -1));

    //MAX SETPOINT 4' ISH
    //cmdElevatorUpPID.whileTrue(new ElevatorPIDCommand(elevatorSubsystem, 1));
    
    //XBOX
    //xbxController.y().whileTrue(new ElevatorCommand(elevatorSubsystem, 1));
    xbxController.pov(180).whileTrue(new IntakeCommand(intakeSubsystem, 0.5, 0.5));
    xbxController.pov(90).whileTrue(new IntakeCommand(intakeSubsystem, -0.3, -0.3));

    //cmdintake.whileTrue(new inIntake(1.0, m_intakeSubsystem));
    //cmdouttake.whileTrue(new inIntake(-1.0, m_intakeSubsystem));
    
    xbxController.axisGreaterThan(1, 0.2).whileTrue(new ArmCommand(armSubsystem, 0.5));
    xbxController.axisLessThan(1, -0.2).whileTrue(new ArmCommand(armSubsystem, -0.5));
    xbxController.axisGreaterThan(5, 0.2).whileTrue(new ElevatorCommand(elevatorSubsystem, -1));
    xbxController.axisLessThan(5, -0.2).whileTrue(new ElevatorCommand(elevatorSubsystem, 1));

    //if (xbxController.getLeftY() > 0.2) new ArmCommand(armSubsystem, 0.5);
    //if (xbxController.getLeftY() > -0.2) new ArmCommand(armSubsystem, -0.5);
    //if (xbxController.getRightY() > 0.2) new ElevatorCommand(elevatorSubsystem, 0.5);
    //if (xbxController.getRightY() > -0.2) new ElevatorCommand(elevatorSubsystem, -0.5);
    
    
    // Calling the Command to move the arm and passing through speed and direction.
    //was 0.50
    cmdArmUp.whileTrue(new ArmCommand(armSubsystem, 0.5));
    cmdArmDown.whileTrue(new ArmCommand(armSubsystem, -0.5));
    //cmdWristPID.whileTrue(new WristPIDCommand(wristSubsystem, 1));
  //  cmdArmPID.whileTrue(new ArmPIDCommand(armSubsystem, 90));
    //zero arm position 
   // zeroArm.whileTrue(new ZeroArmCommand(armSubsystem));

    //xbxController.x().whileTrue(new ArmCommand(armSubsystem, 0.5));
    //xbxController.b().whileTrue(new ArmCommand(armSubsystem, -0.5));
    
    //turncontroller.getPOV() == 0).whileTrue(new ArmCommand(armSubsystem, .5));
    
    // Calling the Command to move the wrist and passing through speed and direction.
    cmdWristUp.whileTrue(new WristCommand(wristSubsystem, .13));
    cmdWristDown.whileTrue(new WristCommand(wristSubsystem, -.13));
    //cmdWristPID.whileTrue(new WristPIDCommand(wristSubsystem, .25, 0.5));
    
    
    xbxController.rightBumper().whileTrue(new WristCommand(wristSubsystem, -0.25));
    xbxController.rightTrigger(0.25).whileTrue(new WristCommand(wristSubsystem, 0.25));


    //Harpoon Commands
    cmdHarpoonUp.whileTrue(new HarpoonCommand(harpoonSubsystem, 1));
    
    cmdHarpoonDown.whileTrue(new HarpoonCommand(harpoonSubsystem, -1));


    //Intake Commands
    cmdIntakeIn.whileTrue(new IntakeCommand(intakeSubsystem, .75, .75));
    cmdIntakeOut.whileTrue(new IntakeCommand(intakeSubsystem, -.75, -.75));

    xbxController.leftBumper().whileTrue(new IntakeCommand(intakeSubsystem, -1, -1));
   
    xbxController.leftTrigger(0.25).whileTrue(new IntakeCommand(intakeSubsystem, 1, 1));
   
    cmdMoveRobotl.whileTrue(new TargetLeftPoleCommand(m_robotDrive, limelightSubsystem, 0, 0, 0));
    cmdMoveRobotr.whileTrue(new TargetLeftPoleCommand(m_robotDrive, limelightSubsystem, 0, 0, 1));
    cmdMoveRobottl.whileTrue(new TargetLeftPoleCommand(m_robotDrive, limelightSubsystem, 0, 0, 2));
    cmdMoveRobottr.whileTrue(new TargetLeftPoleCommand(m_robotDrive, limelightSubsystem, 0, 0, 3));

  
  
    /* 
    cmdMoveRobot.whileTrue(new RunCommand(
      () -> m_robotDrive.drive(
          (0),
          (0),
          (0),
          false),
      m_robotDrive));
   */
    
//    cmdHalfSpeed.whileTrue(new SpeedCommand(m_robotDrive));




//  cmdtopCoral.whileTrue(new ParallelCommandGroup(
 //   new ElevatorPIDCommand(elevatorSubsystem, 0.18),
  //  new ArmPIDCommand(armSubsystem, 0.395),
   // new WristPIDCommand(wristSubsystem, 0.64)));

    xbxController.y().whileTrue(new ParallelCommandGroup(
      new ElevatorPIDCommand(elevatorSubsystem, 0.18),
      new ArmPIDCommand(armSubsystem, 0.395),
      new WristPIDCommand(wristSubsystem, 0.64)));
       
       

      
  //cmdmidCoral.whileTrue(new ParallelCommandGroup(
       //change pid
   //    new ElevatorPIDCommand(elevatorSubsystem, 0.318),
     //  new ArmPIDCommand(armSubsystem, 0.61),
       //new WristPIDCommand(wristSubsystem, 0.58)));

   xbxController.b().whileTrue(new ParallelCommandGroup(
       //change pid
       new ElevatorPIDCommand(elevatorSubsystem, 0.318),
       new ArmPIDCommand(armSubsystem, 0.61),
       new WristPIDCommand(wristSubsystem, 0.58)));
          
      

      
//  cmdbottomCoral.whileTrue(new ParallelCommandGroup(
  //     //change pid
    //   new ElevatorPIDCommand(elevatorSubsystem, 0.48),
      // new ArmPIDCommand(armSubsystem, 0.61),
      // new WristPIDCommand(wristSubsystem, 0.58)));


    xbxController.x().whileTrue(new ParallelCommandGroup(
        //change pid
        new ElevatorPIDCommand(elevatorSubsystem, 0.48),
        new ArmPIDCommand(armSubsystem, 0.61),
        new WristPIDCommand(wristSubsystem, 0.58)));
 
      
  

//pickup croal off ground command here 

   // cmdarmtofloor.whileTrue(new ParallelCommandGroup(
    //  new WristPIDCommand(wristSubsystem, 0.58),
     // new ElevatorPIDCommand(elevatorSubsystem, 0.88),
     //new ArmPIDCommand(armSubsystem, 0.66)));

     xbxController.a().whileTrue(new ParallelCommandGroup(
      new WristPIDCommand(wristSubsystem, 0.58),
      new ElevatorPIDCommand(elevatorSubsystem, 0.88),
     new ArmPIDCommand(armSubsystem, 0.66)));


// pickup coral from coral station 

//cmdarmtofeeder.whileTrue(new ParallelCommandGroup(
//  new WristPIDCommand(wristSubsystem, 0.58),
//  new ElevatorPIDCommand(elevatorSubsystem, 0.59),
// new ArmPIDCommand(armSubsystem, 0.3)));

//xbox human player station

 xbxController.pov(0).whileTrue(new ParallelCommandGroup(
  new WristPIDCommand(wristSubsystem, 0.58),
  new ElevatorPIDCommand(elevatorSubsystem, 0.59),
 new ArmPIDCommand(armSubsystem, 0.3)));


 // Pickup ball from floor 
 ///cmdfloorball.whileTrue(new ParallelCommandGroup(
  //new WristPIDCommand(wristSubsystem, 0.63),
  //new ElevatorPIDCommand(elevatorSubsystem, 0.834),
 //new ArmPIDCommand(armSubsystem, 0.7)));

 

 xbxController.pov(270).whileTrue(new ParallelCommandGroup(
  new WristPIDCommand(wristSubsystem, 0.58),
  new ElevatorPIDCommand(elevatorSubsystem, 0.88),
 new ArmPIDCommand(armSubsystem, 0.66)));


    cmdZeroHeading.whileTrue(new ZeroHeadingCommand(m_robotDrive));


    
    //xintake.whileTrue(new inIntake(1, m_intakeSubsystem)); 
    //xouttake.whileTrue(new inIntake(-1, m_intakeSubsystem));
    //xelevatorUp.whileTrue(new moveElevator(m_elevatorSubsystem));
    //xelevatorDown.whileTrue(new outIntake(m_elevatorSubsystem));
    //xwristUp.whileTrue(new outIntake(m_elevatorSubsystem));
    //xwristDown.whileTrue(new outIntake(m_elevatorSubsystem));

// !!!DO NOT DELETE AFTER THIS LINE, NOT SURE WHAT IT DOES!!!    
  /*   new RunCommand(
      () -> m_robotDrive.drive(
        drive_inputX,
        drive_inputY,
        drive_inputZ,
          true),
      m_robotDrive);
      */

      
  }
  
  

  /**
   * Use this to pass the autonomous command to the main {@link Robot} class.
   *
   * @return the command to run in autonomous
   */
  
    public Command getAutonomousCommand() {
     return autoChooser.getSelected();
    }

  
 
}
