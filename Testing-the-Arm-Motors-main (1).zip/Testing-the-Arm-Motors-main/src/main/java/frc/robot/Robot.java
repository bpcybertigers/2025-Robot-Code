// Copyright (c) FIRST and other WPILib contributors.
// Open Source Software; you can modify and/or share it under the terms of
// the WPILib BSD license file in the root directory of this project.

package frc.robot;


import edu.wpi.first.wpilibj.DataLogManager;
import edu.wpi.first.wpilibj.DriverStation;
import edu.wpi.first.wpilibj.Joystick;
import edu.wpi.first.wpilibj.TimedRobot;
import edu.wpi.first.wpilibj2.command.Command;
import edu.wpi.first.wpilibj2.command.CommandScheduler;
import frc.robot.Constants.OIConstants;

import com.revrobotics.spark.SparkMax;

import java.lang.ModuleLayer.Controller;

import com.revrobotics.spark.SparkLowLevel;
import com.revrobotics.spark.SparkLowLevel.MotorType;
import edu.wpi.first.wpilibj.AnalogPotentiometer;

//camrea
import edu.wpi.first.cameraserver.CameraServer;
import edu.wpi.first.math.MathUtil;
import edu.wpi.first.networktables.NetworkTable;
import edu.wpi.first.networktables.NetworkTableEntry;
import edu.wpi.first.networktables.NetworkTableInstance;

//import frc.robot.LimelightHelpers;
/**
 * The methods in this class are called automatically corresponding to each mode, as described in
 * the TimedRobot documentation. If you change the name of this class or the package after creating
 * this project, you must also update the Main.java file in the project.
 */
public class Robot extends TimedRobot {
  private Command m_autonomousCommand;
  //AnalogPotentiometer potentiometer = new AnalogPotentiometer(3);
  private final RobotContainer m_robotContainer;
  private boolean xcenter = false;
  private boolean ycenter = false;

  /**
   * This function is run when the robot is first started up and should be used for any
   * initialization code.
   */
  public Robot() {
    // Instantiate our RobotContainer.  This will perform all our button bindings, and put our
    // autonomous chooser on the dashboard.
    m_robotContainer = new RobotContainer();
    CameraServer.startAutomaticCapture();
    // Start recording to data log
    DataLogManager.start();

    // Record DS control and joystick data.
    // Change to `false` to not record joystick data.
    DriverStation.startDataLog(DataLogManager.getLog(), true);
    
  }

  NetworkTable table = NetworkTableInstance.getDefault().getTable("limelight");
  NetworkTableEntry tx = table.getEntry("tx");
  NetworkTableEntry ty = table.getEntry("ty");
  NetworkTableEntry ta = table.getEntry("ta");  
  //double tx = LimelightHelpers.getTX("limelight");  // Horizontal offset from crosshair to target in degrees



  /**
   * This function is called every 20 ms, no matter the mode. Use this for items like diagnostics
   * that you want ran during disabled, autonomous, teleoperated and test.
   *
   * <p>This runs after the mode specific periodic functions, but before LiveWindow and
   * SmartDashboard integrated updating.
   */
  @Override
  public void robotPeriodic() {
    // Runs the Scheduler.  This is responsible for polling buttons, adding newly-scheduled
    // commands, running already-scheduled commands, removing finished or interrupted commands,
    // and running subsystem periodic() methods.  This must be called from the robot's periodic
    // block in order for anything in the Command-based framework to work.
    CommandScheduler.getInstance().run();
   //System.out.println(m_robotContainer.getWristEncoder());
   //System.out.println(potentiometer.get());
  }

  /** This function is called once each time the robot enters Disabled mode. */
  @Override
  public void disabledInit() {}

  @Override
  public void disabledPeriodic() {}

  /** This autonomous runs the autonomous command selected by your {@link RobotContainer} class. */
  @Override
  public void autonomousInit() {
    m_autonomousCommand = m_robotContainer.getAutonomousCommand();

    // schedule the autonomous command (example)
    if (m_autonomousCommand != null) {
      m_autonomousCommand.schedule();
    } 

  }

  /** This function is called periodically during autonomous. */
  @Override
  public void autonomousPeriodic() {}

  @Override
  public void teleopInit() {
    // This makes sure that the autonomous stops running when
    // teleop starts running. If you want the autonomous to
    // continue until interrupted by another command, remove
    // this line or comment it out.
    if (m_autonomousCommand != null) {
      m_autonomousCommand.cancel();
    }
  }


  /** This function is called periodically during operator control. */
  @Override
  public void teleopPeriodic() { 
    CommandScheduler.getInstance().run();


    if (RobotContainer.turncontroller.getRawButton(7)) {

      RobotContainer.drive_inputX = MathUtil.applyDeadband(RobotContainer.m_driverController.getY() * .25, OIConstants.kDriveDeadband);
      RobotContainer.drive_inputY = MathUtil.applyDeadband(RobotContainer.m_driverController.getX() * .25, OIConstants.kDriveDeadband);
      RobotContainer.drive_inputZ = MathUtil.applyDeadband(RobotContainer.turncontroller.getZ() * 0.1, 0.05);


    } else {

      RobotContainer.drive_inputX = MathUtil.applyDeadband(RobotContainer.m_driverController.getY() / 2, OIConstants.kDriveDeadband);
      RobotContainer.drive_inputY = MathUtil.applyDeadband(RobotContainer.m_driverController.getX() / 2, OIConstants.kDriveDeadband);
      RobotContainer.drive_inputZ = MathUtil.applyDeadband(-RobotContainer.turncontroller.getZ() * .35, 0.05);


    }





























   /*   if (RobotContainer.turncontroller.getRawButton(4)) {
    //  NetworkTableInstance.getDefault().getTable("limelight").getEntry("ledMode").setNumber(1);

        //choose what input drives the robot
        RobotContainer.drive_inputY = limedriveY;
        RobotContainer.drive_inputZ = limedriveX;
        //sets x speed to half when targeting
        RobotContainer.drive_inputX = -MathUtil.applyDeadband((RobotContainer.m_driverController.getX() / 3), Constants.OIConstants.kDriveDeadband);
 
       
        /* 
          if ((tx.getDouble(0)) > .2) {// Check if X axis is lined up 
          
         limedriveX = .02 * -tx.getDouble(0);
        } else if (tx.getDouble(0) < -.2) {
         limedriveX = .02 * -tx.getDouble(0);
       } else { 
         limedriveX = 0;
       //  xcenter = true;
         } //  Check if Y axis is lined up, Only runs when X is centerd 
 
          if ((ty.getDouble(0)) > .2) {
         limedriveY = .02 * ty.getDouble(0);
        } else if (ty.getDouble(0) < -.2) {
         limedriveY = .02 * ty.getDouble(0);
       } else { 
         limedriveY = 0;
        } 
        limedriveX = RobotContainer.drive_inputX;
       
 
     } else {
       //if limelight is not on set drive to normal and reset all limelight drive variables
         //   RobotContainer.drive_inputY = -MathUtil.applyDeadband(RobotContainer.m_driverController.getY(), Constants.OIConstants.kDriveDeadband);
         //   RobotContainer.drive_inputZ = -MathUtil.applyDeadband(RobotContainer.turncontroller.getZ(), 0.1);
         //   RobotContainer.drive_inputX = -MathUtil.applyDeadband(RobotContainer.m_driverController.getX(), Constants.OIConstants.kDriveDeadband);
 
                                  
       limedriveX = 0;
      
  limedriveY = 0;
       xcenter = false;
       ycenter = false;
        } 

        */
       
     } 
   

  @Override
  public void testInit() {
    // Cancels all running commands at the start of test mode.
    CommandScheduler.getInstance().cancelAll();
  }

  /** This function is called periodically during test mode. */
  @Override
  public void testPeriodic() {
  }

  /** This function is called once when the robot is first started up. */
  @Override
  public void simulationInit() {}

  /** This function is called periodically whilst in simulation. */
  @Override
  public void simulationPeriodic() {}
}
