package frc.robot.commands.Teleop;

import edu.wpi.first.math.controller.PIDController;
import edu.wpi.first.wpilibj.smartdashboard.SmartDashboard;

//import java.util.function.Supplier;

import edu.wpi.first.wpilibj2.command.Command;
import frc.robot.subsystems.ArmSubsystem;

public class ArmPIDCommand extends Command {
  private final ArmSubsystem armSubsystem;
  private final PIDController pidController;
  //private final double speed;
  //private final double speed;

  public ArmPIDCommand(ArmSubsystem armSubsystem, double setpoint) {
    
    this.armSubsystem = armSubsystem;
    //this.speed = speed;
    this.pidController = new PIDController(6, .01, 3);
    pidController.setIZone(.05);
    pidController.setSetpoint(setpoint);
    pidController.setTolerance(0.01);
    addRequirements(armSubsystem);
  }

  @Override
  public void initialize() {
    pidController.reset();
    SmartDashboard.putNumber("ArmSetpoint", pidController.getSetpoint());
  }

  @Override
  public void execute() {
 // pidController.enableContinuousInput(0, 180);
   armSubsystem.moveArm(pidController.calculate(armSubsystem.armEncoderVale()));
    SmartDashboard.putNumber("ArmPosition", armSubsystem.armEncoderVale());
    var error = pidController.getError();
    SmartDashboard.putNumber("ArmError", error);
    SmartDashboard.putNumber("ArmP", pidController.getP() * error);
    SmartDashboard.putNumber("ArmI", pidController.getI() * pidController.getAccumulatedError());

   
   
   
   
   //armSubsystem.moveArm(-speed);
    //System.out.println(armSubsystem.armEncoderVale());
   System.out.println(pidController.calculate(armSubsystem.armEncoderVale()));
  }

  @Override
  public void end(boolean interrupted) {

    armSubsystem.moveArm(0);
  }

  @Override
  public boolean isFinished() {
    
    return pidController.atSetpoint();
    //return false;
  }
}