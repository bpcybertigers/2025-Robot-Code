package frc.robot.commands.Teleop;

//import java.util.function.Supplier;

import edu.wpi.first.wpilibj2.command.Command;
import frc.robot.subsystems.ArmSubsystem;

public class ArmCommand extends Command {
  private final ArmSubsystem armSubsystem;
  private final double armspeed;


  public ArmCommand(ArmSubsystem armSubsystem, double armspeed) {
    
    this.armSubsystem = armSubsystem;
    this.armspeed = armspeed;
    
    addRequirements(armSubsystem);
  }

  @Override
  public void initialize() {
    //System.out.println("Upping");
    
  }

  @Override
  public void execute() {

    
    armSubsystem.moveArm(armspeed);
    
  }

  @Override
  public void end(boolean interrupted) {
    armSubsystem.moveArm(0);
  }

  @Override
  public boolean isFinished() {
    return false;
  }
}