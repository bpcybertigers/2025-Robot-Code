// Copyright (c) FIRST and other WPILib contributors.
// Open Source Software; you can modify and/or share it under the terms of
// the WPILib BSD license file in the root directory of this project.

package frc.robot.commands.Teleop;

import frc.robot.Robot;
import frc.robot.RobotContainer;
import frc.robot.subsystems.DriveSubsystem;
import frc.robot.subsystems.IntakeSubsystem;
import frc.robot.subsystems.LimelightSubsystem;
//import frc.robot.subsystems.DriveSubsystem;
import edu.wpi.first.wpilibj2.command.Command;
// PID import for movement
import edu.wpi.first.math.controller.PIDController;

/** An example command that uses an example subsystem. */
public class DriveCommand extends Command {
 // @SuppressWarnings({"PMD.UnusedPrivateField", "PMD.SingularField"})
  private final DriveSubsystem driveSubsystem;
  private final LimelightSubsystem limelightSubsystem;
  private final PIDController pidControllerx;
  private final PIDController pidControllery;

  /**
   * Creates a new ExampleCommand.
   *
   * @param subsystem The subsystem used by this command.
   */
  public DriveCommand(DriveSubsystem driveSubsystem, LimelightSubsystem limelightSubsystem, double setpointx, double setpointy) {
   this.driveSubsystem = driveSubsystem;
   this.limelightSubsystem = limelightSubsystem;
   this.pidControllerx = new PIDController(0.005, 0, 0.0004);
   this.pidControllery = new PIDController(0.005, 0, 0.0004);
   pidControllerx.setSetpoint(setpointx);
   pidControllerx.setSetpoint(setpointy);
    // Use addRequirements() here to declare subsystem dependencies.
    addRequirements(driveSubsystem);
    addRequirements(limelightSubsystem);
  }

  // Called when the command is initially scheduled.
  @Override
  public void initialize() {}

  // Called every time the scheduler runs while the command is scheduled.
  @Override
  public void execute() {
    
    double speedx = pidControllerx.calculate(4);
    double speedy = pidControllerx.calculate(4);
  

driveSubsystem.drive(-speedy, speedx, 0, false);
  
      //drive(x, y, z,);
  }

  // Called once the command ends or is interrupted.
  @Override
  public void end(boolean interrupted) {}

  // Returns true when the command should end.
  @Override
  public boolean isFinished() {
    return false;
  }
}
