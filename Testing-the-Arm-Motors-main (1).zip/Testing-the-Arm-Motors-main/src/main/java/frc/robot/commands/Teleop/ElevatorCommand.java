package frc.robot.commands.Teleop;

//import java.util.function.Supplier;

import edu.wpi.first.wpilibj2.command.Command;
import frc.robot.subsystems.ElevatorSubsystem;

public class ElevatorCommand extends Command {
  private final ElevatorSubsystem elevatorSubsystem;
  private final double speed;


  public ElevatorCommand(ElevatorSubsystem elevatorSubsystem, double speed) {
    
    this.elevatorSubsystem = elevatorSubsystem;
    this.speed = speed;
    
    addRequirements(elevatorSubsystem);
  }

  @Override
  public void initialize() {
    //System.out.println("Upping");
    
  }

  @Override
  public void execute() {

    
    elevatorSubsystem.moveElevator(speed);
    
  }

  @Override
  public void end(boolean interrupted) {
    elevatorSubsystem.moveElevator(0);
  }

  @Override
  public boolean isFinished() {
    return false;
  }
}