package frc.robot.commands.Teleop;

import edu.wpi.first.math.controller.PIDController;
import edu.wpi.first.wpilibj.smartdashboard.SmartDashboard;

//import java.util.function.Supplier;

import edu.wpi.first.wpilibj2.command.Command;
import frc.robot.subsystems.WristSubsystem;

public class WristPIDCommand extends Command {
  private final WristSubsystem wristSubsystem;
  private final PIDController pidController;
  //private final double speed;
  //private final double speed;

  public WristPIDCommand(WristSubsystem wristSubsystem, double setpoint) {
    
    this.wristSubsystem = wristSubsystem;
    //this.speed = speed;
    this.pidController = new PIDController(15, 0., 0); //did need changing
    pidController.setSetpoint(setpoint);
    addRequirements(wristSubsystem);
  }

  @Override
  public void initialize() {
    pidController.reset();
    SmartDashboard.putNumber("WristSetpoint", pidController.getSetpoint());
    
  }

  @Override
  public void execute() {
   wristSubsystem.moveWrist(-pidController.calculate(wristSubsystem.wristEncoderVale()));
   
    SmartDashboard.putNumber("WristPosition", wristSubsystem.wristEncoderVale());
    var error = pidController.getError();
    SmartDashboard.putNumber("WristError", error);
    SmartDashboard.putNumber("WrristP", pidController.getP() * error);
    SmartDashboard.putNumber("WristI", pidController.getI() * pidController.getAccumulatedError());

   System.out.println(wristSubsystem.wristEncoderVale());
  }

  @Override
  public void end(boolean interrupted) {
    wristSubsystem.moveWrist(0);
  }

  @Override
  public boolean isFinished() {
    return false;
  }
}