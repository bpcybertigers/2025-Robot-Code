// Copyright (c) FIRST and other WPILib contributors.
// Open Source Software; you can modify and/or share it under the terms of
// the WPILib BSD license file in the root directory of this project.

package frc.robot.commands.Teleop;

import frc.robot.Robot;
import frc.robot.RobotContainer;
import frc.robot.subsystems.DriveSubsystem;
import frc.robot.subsystems.IntakeSubsystem;
import frc.robot.subsystems.LimelightSubsystem;
//import frc.robot.subsystems.DriveSubsystem;
import edu.wpi.first.wpilibj2.command.Command;
// PID import for movement
import edu.wpi.first.math.controller.PIDController;
import edu.wpi.first.networktables.NetworkTableInstance;
import edu.wpi.first.wpilibj.smartdashboard.SmartDashboard;

/** An example command that uses an example subsystem. */
public class TargetLeftPoleCommand extends Command {
 // @SuppressWarnings({"PMD.UnusedPrivateField", "PMD.SingularField"})
  private final DriveSubsystem driveSubsystem;
  private final LimelightSubsystem limelightSubsystem;
  private final PIDController pidControllerx;
  private final PIDController pidControllery;
  private double pipeline;
  private boolean xyzero;

  /**
   * Creates a new ExampleCommand.
   *
   * @param subsystem The subsystem used by this command.
   */
  public TargetLeftPoleCommand(DriveSubsystem driveSubsystem, 
  LimelightSubsystem limelightSubsystem, double setpointx, double setpointy, double pipeline) {

   this.pipeline = pipeline;
   this.driveSubsystem = driveSubsystem;
   this.limelightSubsystem = limelightSubsystem;
   this.pidControllerx = new PIDController(0.5, 0, 0);
   this.pidControllery = new PIDController(0.5, 0, 0);
   pidControllerx.setSetpoint(setpointx);
   pidControllery.setSetpoint(setpointy);
   pidControllerx.setTolerance(0.006);
   pidControllery.setTolerance(0.006);
    // Use addRequirements() here to declare subsystem dependencies.
    addRequirements(driveSubsystem);
    addRequirements(limelightSubsystem);
  }

  // Called when the command is initially scheduled.
  @Override
  public void initialize() {

    SmartDashboard.putNumber("XSetpoint", pidControllerx.getSetpoint());
    xyzero = false;

    NetworkTableInstance.getDefault().getTable("limelight").getEntry("pipeline").setNumber(pipeline);

  }

  
 
  // Called every time the scheduler runs while the command is scheduled.
  @Override
  public void execute() {

   
    SmartDashboard.putNumber("XPostition", limelightSubsystem.tx_Get_Double() * 0.03);
    double speedx = pidControllerx.calculate(limelightSubsystem.tx_Get_Double() * 0.03);
    double speedy = pidControllery.calculate(limelightSubsystem.ty_Get_Double() * 0.03);

    SmartDashboard.putNumber("PositionxP", pidControllerx.getP());
  
    System.out.println(limelightSubsystem.tx_Get_Double());

    if (pidControllerx.atSetpoint() && pidControllery.atSetpoint()) {
      xyzero = true;
    }

driveSubsystem.drive(speedy, speedx, /*-RobotContainer.turncontroller.getZ() * 0.25*/ 0, false);
  
      //drive(x, y, z,);
  }

  // Called once the command ends or is interrupted.
  @Override
  public void end(boolean interrupted) {}

  // Returns true when the command should end.
  @Override
  public boolean isFinished() {
    
   return xyzero;
   // return false;
  }
}
