package frc.robot.commands.Teleop;

//import java.util.function.Supplier;

import edu.wpi.first.wpilibj2.command.Command;
import frc.robot.subsystems.WristSubsystem;

public class WristCommand extends Command {
  private final WristSubsystem wristSubsystem;
  private final double wristspeed;


  public WristCommand(WristSubsystem wristSubsystem, double wristspeed) {
    
    this.wristSubsystem = wristSubsystem;
    this.wristspeed = wristspeed;
    
    addRequirements(wristSubsystem);
  }

  @Override
  public void initialize() {
   // System.out.println("Upping");
    
  }

  @Override
  public void execute() {

    
    wristSubsystem.moveWrist(wristspeed);
    //System.out.println(wristspeed);
    
  }

  @Override
  public void end(boolean interrupted) {
    wristSubsystem.moveWrist(0);
  }

  @Override
  public boolean isFinished() {
    return false;
  }
}