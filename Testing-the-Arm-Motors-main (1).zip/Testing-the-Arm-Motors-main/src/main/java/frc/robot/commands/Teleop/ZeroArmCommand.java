package frc.robot.commands.Teleop;

//import java.util.function.Supplier;

import edu.wpi.first.wpilibj2.command.Command;
import frc.robot.subsystems.ArmSubsystem;

public class ZeroArmCommand extends Command {
  private final ArmSubsystem armSubsystem;


  public ZeroArmCommand(ArmSubsystem armSubsystem) {
    
    this.armSubsystem = armSubsystem;
    //this.armspeed = armspeed;
    
    addRequirements(armSubsystem);
  }

  @Override
  public void initialize() {
    //System.out.println("Upping");
    
  }

  @Override
  public void execute() {

    armSubsystem.ZeroEncoder();
    
  }

  @Override
  public void end(boolean interrupted) {

  }

  @Override
  public boolean isFinished() {
    return false;
  }
}