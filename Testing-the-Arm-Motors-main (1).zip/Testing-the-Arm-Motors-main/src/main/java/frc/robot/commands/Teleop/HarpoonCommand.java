package frc.robot.commands.Teleop;

//import java.util.function.Supplier;

import edu.wpi.first.wpilibj2.command.Command;
import frc.robot.subsystems.HarpoonSubsystem;
import frc.robot.subsystems.WristSubsystem;

public class HarpoonCommand extends Command {
  private final HarpoonSubsystem harpoonSubsystem;
  private final double harpoonspeed;


  public HarpoonCommand(HarpoonSubsystem harpoonSubsystem, double harpoonspeed) {
    
    this.harpoonSubsystem = harpoonSubsystem;
    this.harpoonspeed = harpoonspeed;
    
    addRequirements(harpoonSubsystem);
  }

  @Override
  public void initialize() {
  //  System.out.println("Upping");
    
  }

  @Override
  public void execute() {

    
    harpoonSubsystem.moveHarpoon(harpoonspeed);
    
  }

  @Override
  public void end(boolean interrupted) {
    harpoonSubsystem.moveHarpoon(0);
  }

  @Override
  public boolean isFinished() {
    return false;
  }
}