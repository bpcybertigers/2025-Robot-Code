package frc.robot.commands.Teleop;

import com.ctre.phoenix6.configs.Pigeon2FeaturesConfigs;

import edu.wpi.first.math.controller.PIDController;
import edu.wpi.first.wpilibj.smartdashboard.SmartDashboard;

//import java.util.function.Supplier;

import edu.wpi.first.wpilibj2.command.Command;
import frc.robot.subsystems.ElevatorSubsystem;

public class ElevatorPIDCommand extends Command {
  private final ElevatorSubsystem elevatorSubsystem;
  private final PIDController pidController;
  //private final double speed;

  public ElevatorPIDCommand(ElevatorSubsystem elevatorSubsystem, double setpoint) {
    
    this.elevatorSubsystem = elevatorSubsystem;
    //this.speed = speed;
    this.pidController = new PIDController(10, .4, 7);
    pidController.setSetpoint(setpoint);
    pidController.setIZone(.05);
    addRequirements(elevatorSubsystem);
    pidController.setTolerance(0.03);
  }

  @Override
  public void initialize() {
    pidController.reset();
    

    SmartDashboard.putNumber("ELevatorSetpoint", pidController.getSetpoint());
  }

  @Override
  public void execute() {
   //pidController.enableContinuousInput(0, 1);
   
   elevatorSubsystem.moveElevator(-pidController.calculate(elevatorSubsystem.getEncoderMeters()));
    SmartDashboard.putNumber("ELevatorPosition", elevatorSubsystem.getEncoderMeters());

    var error = pidController.getError();

    SmartDashboard.putNumber("ELevatorError", error);
    SmartDashboard.putNumber("ELevatorP", pidController.getP() * error);
    SmartDashboard.putNumber("ELevatorI", pidController.getI() * pidController.getAccumulatedError());


    if (pidController.atSetpoint()) {
      System.err.println("done");
    }
  //  
      System.out.println(elevatorSubsystem.getEncoderMeters());
  }

  @Override
  public void end(boolean interrupted) {
    elevatorSubsystem.moveElevator(0);
  }

  @Override
  public boolean isFinished() {
    //return false;
   return pidController.atSetpoint();
    
   
     
  }
}