package frc.robot.commands.Teleop;

//import java.util.function.Supplier;

import edu.wpi.first.wpilibj2.command.Command;
import frc.robot.subsystems.DriveSubsystem;

public class ZeroHeadingCommand extends Command {
  private final DriveSubsystem drivSubsystem;


  public ZeroHeadingCommand(DriveSubsystem driveSubsystem) {
    
    this.drivSubsystem = driveSubsystem;
    //this.armspeed = armspeed;
    
    addRequirements(driveSubsystem);
  }

  @Override
  public void initialize() {
    //System.out.println("Upping");
    
  }

  @Override
  public void execute() {

    drivSubsystem.zeroHeading();
    
  }

  @Override
  public void end(boolean interrupted) {

  }

  @Override
  public boolean isFinished() {
    return false;
  }
}