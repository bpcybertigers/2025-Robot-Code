package frc.robot.commands.Teleop;

//import java.util.function.Supplier;

import edu.wpi.first.wpilibj2.command.Command;
import frc.robot.subsystems.IntakeSubsystem;

public class IntakeCommand extends Command {
  private final IntakeSubsystem intakeSubsystem;
  private final double intakespeedl;
  private final double intakespeedr;


  public IntakeCommand(IntakeSubsystem intakeSubsystem, double intakespeedl, double intakespeedr) {
    
    this.intakeSubsystem = intakeSubsystem;
    this.intakespeedl = intakespeedl;
    this.intakespeedr = intakespeedr;
    
    addRequirements(intakeSubsystem);
  }

  @Override
  public void initialize() {
    //System.out.println("Upping");
    
  }

  @Override
  public void execute() {

    
    intakeSubsystem.moveintake(intakespeedl, intakespeedr);
    
  }

  @Override
  public void end(boolean interrupted) {
    intakeSubsystem.moveintake(0, 0);
  }

  @Override
  public boolean isFinished() {
    return false;
  }
}