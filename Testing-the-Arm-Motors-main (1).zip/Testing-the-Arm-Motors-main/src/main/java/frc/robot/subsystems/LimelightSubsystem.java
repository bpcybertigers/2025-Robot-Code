package frc.robot.subsystems;

// Imports for limelight 
import edu.wpi.first.networktables.NetworkTable;
import edu.wpi.first.networktables.NetworkTableEntry;
import edu.wpi.first.networktables.NetworkTableInstance;
import edu.wpi.first.wpilibj2.command.Command;
import edu.wpi.first.wpilibj2.command.SubsystemBase;


public class LimelightSubsystem extends SubsystemBase {

  NetworkTable table = NetworkTableInstance.getDefault().getTable("limelight");
  NetworkTableEntry tx = table.getEntry("tx");
  NetworkTableEntry ty = table.getEntry("ty");
  NetworkTableEntry ta = table.getEntry("ta"); 
   
    
    public LimelightSubsystem() {}
         public Command limelightMethodCommand() {
    // Inline construction of command goes here.
    // Subsystem::RunOnce implicitly requires `this` subsystem.
    return runOnce(
        () -> {
          /* one-time action goes here */

          
        });
  }
    

    @Override
    public void periodic() {
        // This method will be called once per scheduler run
       // tx.getDouble(0);
        //ty.getDouble(0);
        //ta.getDouble(0);

    }

   // public double armEncoderVale() {
       


   public double tx_Get_Double() {
       // This method will be called once per scheduler run
       return tx.getDouble(0);
   }
   
   public double ty_Get_Double() {
    // This method will be called once per scheduler run
    return ty.getDouble(0);
}


}
   