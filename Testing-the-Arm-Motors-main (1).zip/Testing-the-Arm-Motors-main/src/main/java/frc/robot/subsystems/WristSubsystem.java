package frc.robot.subsystems;

import com.revrobotics.spark.SparkMax;
import com.revrobotics.AbsoluteEncoder;
import com.revrobotics.RelativeEncoder;
import com.revrobotics.spark.SparkLowLevel.MotorType;

import edu.wpi.first.wpilibj.AnalogPotentiometer;
import edu.wpi.first.wpilibj2.command.Command;
import edu.wpi.first.wpilibj2.command.SubsystemBase;


import frc.robot.Constants.ElevatorConstants;

public class WristSubsystem extends SubsystemBase {

    private final SparkMax wrist = new SparkMax(ElevatorConstants.kTopWristPort, MotorType.kBrushless);
   // private AbsoluteEncoder enn = wrist.getAbsoluteEncoder();
   // private RelativeEncoder enn = wrist.getAlternateEncoder();
   private AnalogPotentiometer potentiometer2 = new AnalogPotentiometer(2);
    /** Creates a new Elevator. */
    public WristSubsystem() {}

    public Command wristMethodCommand() {
    // Inline construction of command goes here.
    // Subsystem::RunOnce implicitly requires `this` subsystem.
    return runOnce(
        () -> {
          /* one-time action goes here */

          
        });
  }
    @Override
    public void periodic() {
        // This method will be called once per scheduler run
    }

    public double wristEncoderVale() {
       return potentiometer2.get();
   } 

    public void moveWrist(double wristspeed) {
        System.out.println("wrist" + potentiometer2.get());
        //wrist.set(wristspeed);
        //.681
        //0.603
              if (wristspeed < 0) {
             if (potentiometer2.get() < 0.65) {
                 wrist.set(wristspeed);
     
              } else {
                 wrist.set(0);
             }
           }
              else if (wristspeed > 0) {
               if (potentiometer2.get() > 0.564) {
                 wrist.set(wristspeed);
              
              }else {
              

                 wrist.set(0);
              } 
             } else {
                 wrist.set(0);
        }
    }

}
   