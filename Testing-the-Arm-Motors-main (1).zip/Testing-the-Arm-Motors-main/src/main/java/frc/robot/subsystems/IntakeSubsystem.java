package frc.robot.subsystems;

import com.revrobotics.spark.SparkMax;
import com.revrobotics.spark.SparkLowLevel.MotorType;

import edu.wpi.first.wpilibj2.command.Command;
import edu.wpi.first.wpilibj2.command.SubsystemBase;


import frc.robot.Constants.IntakeConstants;

public class IntakeSubsystem extends SubsystemBase {

    private final SparkMax leftIntake = new SparkMax(IntakeConstants.kLeftIntakePort, MotorType.kBrushless);
    private final SparkMax rightIntake = new SparkMax(IntakeConstants.kRightIntakePort, MotorType.kBrushless);
   // private final SparkMax arm = new SparkMax(ElevatorConstants.kBottomWristPort, MotorType.kBrushless);
    //private final SparkMax wrist = new SparkMax(ElevatorConstants.kTopWristPort, MotorType.kBrushless);

    /** Creates a new Elevator. */
    public IntakeSubsystem() {}

     public Command intakeMethodCommand() {
    // Inline construction of command goes here.
    // Subsystem::RunOnce implicitly requires `this` subsystem.
    return runOnce(
        () -> {
          /* one-time action goes here */

          
        });
  }
    @Override
    public void periodic() {
        // This method will be called once per scheduler run
    }


    public void moveintake(double intakespeedl, double intakespeedr) {
      //  System.out.println("going up or down?");
        leftIntake.set(intakespeedl);
        rightIntake.set(-intakespeedr);
     
    }

    // public void stopintake() {
    //     leftIntake.set(0);
    //     rightIntake.set(0);
    // }

}
   