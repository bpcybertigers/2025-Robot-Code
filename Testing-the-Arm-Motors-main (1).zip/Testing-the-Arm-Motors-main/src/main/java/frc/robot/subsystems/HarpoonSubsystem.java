package frc.robot.subsystems;

import com.revrobotics.spark.SparkMax;
import com.revrobotics.spark.SparkLowLevel.MotorType;

import edu.wpi.first.wpilibj2.command.SubsystemBase;


//import frc.robot.Constants.ElevatorConstants;

public class HarpoonSubsystem extends SubsystemBase {

   private final SparkMax Harpoon = new SparkMax(7, MotorType.kBrushed);
    /** Creates a new Elevator. */
    public HarpoonSubsystem() {}

    @Override
    public void periodic() {
        // This method will be called once per scheduler run
    }

    public void moveHarpoon(double harpoonspeed) {
       
       Harpoon.set(harpoonspeed);
    }

}
   