package frc.robot.subsystems;

import com.revrobotics.spark.SparkMax;
import com.revrobotics.AbsoluteEncoder;
import com.revrobotics.RelativeEncoder;
import com.revrobotics.spark.SparkLowLevel.MotorType;

import edu.wpi.first.wpilibj.AnalogPotentiometer;
import edu.wpi.first.wpilibj2.command.Command;
import edu.wpi.first.wpilibj2.command.SubsystemBase;


import frc.robot.Constants.ElevatorConstants;

public class ArmSubsystem extends SubsystemBase {

    private final SparkMax arm = new SparkMax(ElevatorConstants.kBottomWristPort, MotorType.kBrushless);
    private RelativeEncoder enn = arm.getEncoder();
    private AnalogPotentiometer potentiometer1 = new AnalogPotentiometer(1);
   
    /** Creates a new Elevator. */
    public ArmSubsystem() {}

     public Command armMethodCommand() {
    // Inline construction of command goes here.
    // Subsystem::RunOnce implicitly requires `this` subsystem.
    return runOnce(
        () -> {
          /* one-time action goes here */

          
        });
  }
    @Override
    public void periodic() {
        // This method will be called once per scheduler run
        
       // String formattedPostition = String.format("%.4f", potentiometer1.get());
        //System.out.println(formattedPostition);
    }

    public double armEncoderVale() {
        return potentiometer1.get();

    }
    public void moveArm(double armspeed) {

        System.out.println("Barm" + potentiometer1.get());
        //arm.set(armspeed);
        //0.060855
        //0.68
           if (armspeed > 0) {
               if (potentiometer1.get() < .79) {
                   arm.set(armspeed);
     
                } else {
                   arm.set(0);
                }
             }
                else if (armspeed < 0) {
                 if (potentiometer1.get() > 0.037) {
                   arm.set(armspeed);
              
                } else {
              
                  arm.set(0);
            } 
               } else {
                   arm.set(0);
              }
        } 

    public void ZeroEncoder() {

        enn.setPosition(0);
    }
    // public void stopArm() {
    //     arm.set(0);
    // }

}
   