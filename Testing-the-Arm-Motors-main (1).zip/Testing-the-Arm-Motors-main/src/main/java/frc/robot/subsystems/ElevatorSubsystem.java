package frc.robot.subsystems;

import edu.wpi.first.wpilibj.DutyCycle;
import edu.wpi.first.wpilibj.DutyCycleEncoder;
import edu.wpi.first.wpilibj.Encoder;

//import com.revrobotics.sim.SparkMaxAlternateEncoderSim;
import com.revrobotics.spark.SparkMax;
import com.revrobotics.spark.SparkMaxAlternateEncoder;
//import com.revrobotics.spark.SparkMaxAlternateEncoder;
import com.revrobotics.spark.SparkLowLevel.MotorType;
import com.revrobotics.RelativeEncoder;
import com.revrobotics.AbsoluteEncoder;
import edu.wpi.first.wpilibj.AnalogPotentiometer;
import edu.wpi.first.wpilibj2.command.Command;
import edu.wpi.first.wpilibj2.command.SubsystemBase;
import frc.robot.Constants.ElevatorConstants;
//import com.revrobotics.spark.SparkRelativeEncoder;

public class ElevatorSubsystem extends SubsystemBase {
  
    private final SparkMax leftElevator = new SparkMax(ElevatorConstants.kLeftElevatorPort, MotorType.kBrushed);
    private final SparkMax rightElevator = new SparkMax(ElevatorConstants.kRightElevatorPort, MotorType.kBrushed);
   // private final Encoder encoder = new Encoder(0, 1);
    private RelativeEncoder enn = rightElevator.getEncoder();
    private AnalogPotentiometer potentiometer = new AnalogPotentiometer(3);


    private final double bottomLimit = 0.875;
    private final double toplimit = 0.115;
    
    //  enn = leftElevator.getEncoder();
    
     //private final double currentPoition = 0;
    //double lastPosition = 0.0;

  //This is the conversion value that changes pulces to feet, IDK how it works its just right.
    private final double kEncoderTick2Meter = 3.9;
   //  int revcount = 0;
//1.5 turns per foot travled 
    //private double continuousDistance;
   // private double currentPoition = enn.getPosition();
   
    
    /** Creates a new Elevator. */
    public ElevatorSubsystem() {}

    public Command elevatorMethodCommand() {
    // Inline construction of command goes here.
    // Subsystem::RunOnce implicitly requires `this` subsystem.
    return runOnce(
        () -> {
          /* one-time action goes here */

          
        });
  }

    @Override
    public void periodic() {
          

      
          /*  
            if (currentPoition < 0.1 && lastPosition > 0.9) {
            revcount++;
            //System.out.println("works");
        } else if (currentPoition > 0.9 && lastPosition < 0.1) {
            revcount--;
        }
        lastPosition = currentPoition;
         continuousDistance = (revcount += currentPoition);
       // String formattedPostition = String.format("%.2f", continuousDistance);
        //System.out.println(formattedPostition);
           */ 
    }
    
  

   
    public double getEncoderMeters() {
      
   //  encoder.setDistance
      // return enn.getPosition() / kEncoderTick2Meter;
      return potentiometer.get();
     }
    public void moveElevator(double speed) {
      //  System.out.println("going up or down?");
      //leftElevator.set(-speed);
       // rightElevator.set(speed);
        // 0.72 = 1st lvl
  // 0.56 = 1 foot
System.out.println("Eleavator" + potentiometer.get());
        if (speed < 0) {
          if (potentiometer.get() < bottomLimit) {
            leftElevator.set(-speed);
            rightElevator.set(speed);
   
           } else {
              leftElevator.set(0);
              rightElevator.set(0);
           }
        }
           else if (speed > 0) {
            if (potentiometer.get() > toplimit) {
              leftElevator.set(-speed);
            rightElevator.set(speed);
            
           } else {
            
              leftElevator.set(0);
              rightElevator.set(0);
           } 
          } else {
            leftElevator.set(0);
            rightElevator.set(0);
         } }
    // public void stopElevator() {
    //   leftElevator.set(0);
    //   rightElevator.set(0);


    public void moveElevatorPID(double speedPID) {
      //  System.out.println("going up or down?");
      //leftElevator.set(-speed);
       // rightElevator.set(speed);
        // 0.72 = 1st lvl
  // 0.56 = 1 foot
System.out.println("Eleavator" + potentiometer.get());
        if (speedPID < 0) {
          if (potentiometer.get() > bottomLimit) {
            leftElevator.set(speedPID);
            rightElevator.set(-speedPID);
   
           } else {
              leftElevator.set(0);
              rightElevator.set(0);
           }
        }
           else if (speedPID > 0) {
            if (potentiometer.get() < toplimit) {
              leftElevator.set(-speedPID);
            rightElevator.set(speedPID);
            
           } else {
            
              leftElevator.set(0);
              rightElevator.set(0);
           } 
          } else {
            leftElevator.set(0);
            rightElevator.set(0);
         }
    // public void stopElevator() {
    //   leftElevator.set(0);
    //   rightElevator.set(0);
    
    // }
        }
}
   